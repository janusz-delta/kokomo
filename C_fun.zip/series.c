
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

char *series(double x,double eps,int M){

//1+(1/3)*x+(1*4/3*6)*x2+(1*4*7/3*6*9)*x3+(1*4*7*10/3*6*9*12)*x4...
char li[200];
char *yn;
int delta; //przyrost mno�nika
int N;     //licznik element�w
double d,e,f;
double xx,nu,de,nu_mult,de_mult;
delta=3;    //przyrost mno�nika
nu_mult=1;  //mno�nik licznika
de_mult=3;  //mno�nik mianownika
nu=1;       //licznik
de=3;       //mianownik
xx=x;

f=1.0+(nu/de)*xx; //pierwsze dwa elementy szeregu

N=2; //zaczynamy od trzeciego
while (N<=M){
 N++;
 nu_mult+=delta;
 de_mult+=delta;
 nu*=nu_mult;
 de*=de_mult;
 xx*=x;
 e=xx*nu/de;
 f+=e;
 //printf("%4d %e %e %e %e %e %e %e\n",N,xx,nu_mult,de_mult,nu,de,e,f);
 if(fabs(e)<eps){break;}
}
yn="tak";

if(N>M){yn="nie";}

sprintf(li,"%f  %f %5d %6s\n",x,f,N,yn);

return li;}



int main(int argc, char* argv[]){
FILE *out;
char *endptr;

double a,b,dx,eps;
int M;
double x;
int N;

if(argc!=6){
 printf("\n Uruchomienie: \n\n series a b dx eps M \n\n gdzie:\n\n a - start X\n b - stop X\n dX - przyrost X\n eps - wymagana dokladnosc\n M - maksymalna liczba elementow szeregu\n");
 getch();
return 101;}


a=strtod(argv[1],&endptr);
b=strtod(argv[2],&endptr);
dx=strtod(argv[3],&endptr);
eps=strtod(argv[4],&endptr);
M=(int)strtol(argv[5],&endptr,10);

if ((out=fopen("series.txt","wt"))==NULL){
 printf("\n Nie mozna utworzyc pliku...\n");
 getch();
 return 1;}

fprintf(out,"%s\n","series.exe\nparametry:");
fprintf(out,"a %f\nb %f\ndx %f\neps %e\nM %d\n\n",a,b,dx,eps,M);

x=a;
N=0;
while (x<=b){
 fprintf(out,"%5d| %s",N,series(x,eps,M));
 N++;
 x=a+N*dx;
}

fclose(out);

printf("\n%s\n%s\n"," dane i wyniki w pliku 'series.txt'"," przycisnij cos...");
getch();
return 0;}

